drop tablespace TPCE including contents and datafiles;
