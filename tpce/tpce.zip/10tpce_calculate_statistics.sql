connect / as sysdba
exec dbms_stats.gather_schema_stats(ownname => 'TPCE', options => 'GATHER', degree => 16);

