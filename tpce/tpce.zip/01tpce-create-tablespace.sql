create bigfile tablespace "TPCE" datafile '/u02/app/oracle/oradata2/TPCE01.dbf' size 90G LOGGING EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO ;
